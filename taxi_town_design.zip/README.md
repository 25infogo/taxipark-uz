TaxiPark — Modern React + Tailwind Design (Demo)
------------------------------------------------
How to run locally:
1. npm install
2. npm run dev
(Project created for Vite + React)

Notes:
- Tailwind is configured. After npm install you can run dev server.
- Framer Motion is included for smooth animations.
- This is a frontend-only demo (no backend). Order form will POST to /api/orders if you connect backend.
