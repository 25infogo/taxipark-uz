import React, {useState} from 'react'
import { motion } from 'framer-motion'

export default function OrderForm(){
  const [phone, setPhone] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [status, setStatus] = useState('')

  async function handleSubmit(e){
    e.preventDefault()
    setStatus('Отправка...')
    try{
      const res = await fetch('/api/orders', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({phone, from, to})
      })
      if(res.ok) setStatus('Заказ отправлен — оператор свяжется')
      else setStatus('Ошибка отправки')
    }catch(err){
      setStatus('Ошибка сети')
    }
  }

  return (
    <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{delay:0.4}} className='bg-white p-6 rounded-2xl shadow-lg'>
      <h3 className='text-lg font-semibold mb-2'>Быстрый заказ</h3>
      <form onSubmit={handleSubmit} className='grid gap-3'>
        <div className='flex gap-2'>
          <input className='flex-1 border p-3 rounded' placeholder='Откуда' value={from} onChange={e=>setFrom(e.target.value)} />
        </div>
        <input className='border p-3 rounded' placeholder='Куда' value={to} onChange={e=>setTo(e.target.value)} />
        <input className='border p-3 rounded' placeholder='+998 90 123 45 67' value={phone} onChange={e=>setPhone(e.target.value)} />
        <button className='mt-2 bg-taxiYellow text-taxiBlack py-3 rounded-full font-semibold'>Вызвать машину</button>
      </form>
      <p className='mt-3 text-sm text-gray-500'>{status}</p>
    </motion.div>
  )
}
