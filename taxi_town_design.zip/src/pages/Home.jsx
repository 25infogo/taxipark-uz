import React from 'react'
import OrderForm from '../components/OrderForm'
import { motion } from 'framer-motion'

export default function Home(){
  return (
    <div className='min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-900'>
      <header className='flex items-center justify-between px-8 py-6'>
        <div className='flex items-center gap-3'>
          <div className='w-10 h-10 rounded-full bg-taxiYellow flex items-center justify-center font-bold text-taxiBlack'>TP</div>
          <div className='text-xl font-semibold'>TaxiPark</div>
        </div>
        <nav className='flex items-center gap-4'>
          <a className='px-4 py-2 rounded hover:bg-gray-100' href='#order'>Заказать</a>
          <a className='px-4 py-2 rounded hover:bg-gray-100' href='#drivers'>Водителям</a>
          <a className='px-4 py-2 rounded hover:bg-gray-100' href='#contacts'>Контакты</a>
        </nav>
      </header>

      <main className='px-8'>
        <section className='relative bg-[url("/hero.jpg")] bg-cover bg-center rounded-2xl overflow-hidden py-24 px-8' style={{boxShadow:'inset 0 0 0 2000px rgba(0,0,0,0.35)'}}>
          <div className='max-w-5xl mx-auto text-white flex flex-col md:flex-row items-center gap-12'>
            <div className='md:w-1/2'>
              <motion.h1 initial={{y:20, opacity:0}} animate={{y:0, opacity:1}} transition={{delay:0.1}} className='text-4xl md:text-5xl font-extrabold leading-tight'>
                🚖 Ваше такси — всегда рядом
              </motion.h1>
              <motion.p initial={{y:20, opacity:0}} animate={{y:0, opacity:1}} transition={{delay:0.2}} className='mt-4 text-lg max-w-xl'>
                Быстро, удобно и безопасно. Закажите машину за пару кликов и следите за поездкой в реальном времени.
              </motion.p>
              <motion.div initial={{y:20, opacity:0}} animate={{y:0, opacity:1}} transition={{delay:0.3}} className='mt-6 flex gap-4'>
                <a href='#order' className='bg-taxiYellow text-taxiBlack px-6 py-3 rounded-full font-semibold shadow-lg hover:scale-[1.02] transition'>Заказать сейчас</a>
                <a href='#drivers' className='bg-white text-black px-4 py-3 rounded-full font-medium opacity-90 hover:opacity-100 transition'>Стать водителем</a>
              </motion.div>
            </div>

            <div className='md:w-1/2'>
              <OrderForm />
            </div>
          </div>
        </section>

        <section id='drivers' className='mt-12 max-w-5xl mx-auto'>
          <h2 className='text-2xl font-bold mb-4'>Для водителей</h2>
          <div className='grid md:grid-cols-2 gap-6 items-center'>
            <div className='p-6 bg-white rounded-2xl shadow'>
              <h3 className='text-lg font-semibold'>Зарабатывайте с нами</h3>
              <p className='mt-2 text-sm text-gray-600'>Гибкий график, достойные выплаты и прозрачные условия.</p>
              <button className='mt-4 bg-taxiYellow text-taxiBlack px-4 py-2 rounded-full font-semibold'>Присоединиться</button>
            </div>
            <img className='rounded-2xl w-full h-56 object-cover' src='/driver.jpg' alt='driver' />
          </div>
        </section>

        <section id='about' className='mt-12 max-w-5xl mx-auto'>
          <h2 className='text-2xl font-bold mb-4'>О компании</h2>
          <div className='grid md:grid-cols-3 gap-6'>
            <div className='p-6 bg-white rounded-2xl text-center shadow'>
              <div className='text-3xl font-bold'>200+</div>
              <div className='mt-2 text-sm text-gray-600'>машин в автопарке</div>
            </div>
            <div className='p-6 bg-white rounded-2xl text-center shadow'>
              <div className='text-3xl font-bold'>⭐ 10k+</div>
              <div className='mt-2 text-sm text-gray-600'>довольных клиентов</div>
            </div>
            <div className='p-6 bg-white rounded-2xl text-center shadow'>
              <div className='text-3xl font-bold'>24/7</div>
              <div className='mt-2 text-sm text-gray-600'>поддержка и приём заказов</div>
            </div>
          </div>
        </section>

        <footer id='contacts' className='mt-16 bg-taxiBlack text-white rounded-2xl p-8'>
          <div className='max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6'>
            <div>
              <div className='text-3xl font-bold'>📞 1234</div>
              <div className='text-sm text-gray-300 mt-1'>короткий номер для заказа</div>
            </div>
            <div className='flex gap-4'>
              <a className='bg-white text-black px-4 py-2 rounded-full'>App Store</a>
              <a className='bg-white text-black px-4 py-2 rounded-full'>Google Play</a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}
